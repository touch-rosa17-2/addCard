-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2023 at 11:11 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biu_db_card`
--

-- --------------------------------------------------------

--
-- Table structure for table `biu_tbl_card`
--

CREATE TABLE `biu_tbl_card` (
  `cardID` int(50) NOT NULL,
  `cardImage` varchar(200) NOT NULL,
  `cardName` varchar(50) NOT NULL,
  `cardAge` int(3) NOT NULL,
  `cardPhonenumber` int(15) NOT NULL,
  `cardRole` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `biu_tbl_card`
--

INSERT INTO `biu_tbl_card` (`cardID`, `cardImage`, `cardName`, `cardAge`, `cardPhonenumber`, `cardRole`) VALUES
(47, 'testing', 'Test', 20, 12121212, ''),
(48, 'testing', 'Test', 20, 12121212, ''),
(49, 'testing', 'Test', 20, 12121212, ''),
(50, 'testing', 'Test', 20, 12121212, ''),
(51, 'testing', 'Test', 20, 12121212, ''),
(52, 'testing', 'Test', 20, 12121212, ''),
(53, 'testing', 'Test', 20, 12121212, ''),
(54, 'testing', 'Test', 20, 12121212, ''),
(55, 'testing', 'Test', 20, 12121212, ''),
(56, 'testing', 'Test', 20, 12121212, ''),
(57, 'testing', 'Test', 20, 12121212, ''),
(58, 'testing', 'Test', 20, 12121212, ''),
(59, 'testing', 'Test', 20, 12121212, ''),
(60, 'testing', 'Test', 20, 12121212, ''),
(61, 'testing', 'Test', 20, 12121212, ''),
(62, 'testing', 'Test', 20, 12121212, ''),
(63, 'testing', 'Test', 20, 12121212, ''),
(64, 'testing', 'Test', 20, 12121212, ''),
(65, 'testing', 'Test', 20, 12121212, ''),
(66, 'testing', 'Test', 20, 12121212, ''),
(67, 'testing', 'Test', 20, 12121212, ''),
(68, 'testing', 'Test', 20, 12121212, ''),
(69, 'testing', 'Test', 20, 12121212, ''),
(70, 'testing', 'Test', 20, 12121212, ''),
(71, 'testing', 'Test', 20, 12121212, ''),
(72, 'testing', 'Test', 20, 12121212, ''),
(73, 'testing', 'Test', 20, 12121212, ''),
(74, 'testing', 'KK', 20, 23, ''),
(75, 'testing', 'KK', 20, 23, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biu_tbl_card`
--
ALTER TABLE `biu_tbl_card`
  ADD PRIMARY KEY (`cardID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `biu_tbl_card`
--
ALTER TABLE `biu_tbl_card`
  MODIFY `cardID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
