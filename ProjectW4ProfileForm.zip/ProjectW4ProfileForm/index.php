<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style/style.css">
    <link rel="stylesheet" href="assets/style/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style/bootstrap.min.js">
    <style>
        body{
            background:gray;
        }
        .box{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            background:yellow;
            z-index: 1000;
            height:500px;
            border-radius:10px;
            padding:10px;
            display:none;
            visibility:hidden;
            opacity:0;
            transition: opacity 2s;
        }
        #closeFormBox{
            position:absolute;
            top:23.4%;
            right:40.5%;
            position:fixed;
            z-index: 1100;
            display:none;
            visibility:hidden;
            opacity:0;
            transition: opacity 2s;
        }
        /* hide scrollbar (chrome,safari,opera) */
        .overflow-auto::-webkit-scrollbar{
            display:none;
        }
        .overflow-auto{
            -ms-overflow-style:none;
            scrollbar-width:none;
        }
        .box form{
            padding: 20px 50px;
            font-size:1.5rem;
        }
        /* .divWrap{
            filter:blur(2px);
        } */
        .profilePreviewBx{
            margin:auto;
            width:150px;
            height:150px;
            border-radius:50%;
            display:flex;
            justify-content:center;
            align-items:center;

            position:relative;
            /* overflow:hidden; */
        }
        .dob{
            font-size:1.1rem;
        }
        .profilePreviewBx input{
            width:150px;
            height:150px;
            border-radius:50%;
            cursor: pointer;
            position:absolute;
            opacity: 0;
        }
        #profilePreview{
            width:150px;
            height:150px;
            border-radius:50%;
            cursor: pointer;
        }
        .buttonClose {
            font-size:1.4rem;
            background-color: brown;
            color:black;
            position:absolute;
            bottom:-20%;
            left:50%;
            transform:translate(-50%,-50%);
        }
        .btn{
            margin:auto;
        }
        .loarding{
            width:100px;
            height:100px;
            position:absolute;
            /* opacity: 0.5; */
            mix-blend-mode:multiply;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);

        }
        /* edit btn */
        #editBox{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            background:aqua;
            z-index: 1000;
            height:600px;
            border-radius:10px;
            padding:10px;
            display:none;
        }
        #editBoxBtn{
            position:absolute;
            top:18%;
            right:40.5%;
            position:fixed;
            z-index: 1100;
            display:none;
            visibility:hidden;
            opacity:0;
            transition: opacity 2s;
        }
        #editBox form{
            padding: 20px 50px;
            font-size:1.5rem;
        }

    </style>
    <title>Sign UP</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 bg-info text-center text-dark p-3">
                <h1>Add Card Info</h1>
                <div class="btnDisplayForm btn btn-primary btn-width-5" onclick="displayForm()">Add Here</div>
            </div>
            <div class="col-lg-4"></div>
            <div class="col-lg-4">
                <div class="btn btn-danger text-right" id="closeFormBox" onclick="clearDisplayForm()">X</div>
                <div class="box overflow-auto overlay" id="formBox">
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
                        <div class="circle profilePreviewBx circle-sm bg-secondary" >
                            <input type="file" name="profileImage" id="profileInput" onchange="preview()" value="">
                            <img src="" alt="" id="profilePreview"  value="">
                            <button type="button" onclick="cancelPreview()" class="buttonClose btn btn-close btn-close-warning" aria-label="Close"></button>
                            <!-- <img src="assets/icons/Spinner-1s-200px.svg" class="loarding" alt=""> -->
                        </div>
                        <!-- <input type="text" name="getImgName" id="getImgName" value=""> -->
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="name" required value="" >
                        <label for="dob">Date of Birth</label>
                        <div class="dob">
                            <select name="day" id="day">
                                <option value="" hidden>Day</option>
                            </select>
                            <select name="month" id="month">
                            </select>
                            <select name="year" id="year">
                                <option value="" hidden>Year</option>
                            </select>
                        </div>
                        <label for="phoneNumber">Phone Number</label>
                        <input type="number" name="phoneNumber" class="form-control" required value="">
                        <label for="role">Role</label>
                        <input type="text" name="role" class="form-control" value="">
                        <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary mt-3 text-center">
                    </form>
                </div>
            </div>
            <div class="col-lg-4"></div>
        </div>
        <br><br>
        <?php 
            require "config.php";
            $object = new configClass;
            
            // set value
            $name=$day =$month =$year=$age =$phoneNumber =$role  = null;

            if(isset($_POST["btnSubmit"])){
                // $profileImage = $_FILES["profileImage"];
                $profileImage = $_FILES["profileImage"];
                // if(move_uploaded_file($profileImage["tmp_name"],"assets/img/".$profileImage["name"])){
                //     echo
                //     "<script> alert('Image uploaded...');</script>";
                // }
                // $getImgName = $_POST["getImgName"];
                $profileImageFake = "testing";
                $name         = $_POST["name"];
                // dob
                $day   = $_POST["day"];
                $month = $_POST["month"];
                $year  = $_POST["year"];
                $age   = "20";
                $phoneNumber  = $_POST["phoneNumber"];
                $role  = $_POST["role"];

                $table = "biu_tbl_card";
                // insert data to Mysql
                // normal form to insert    
                $sql  = "INSERT INTO $table VALUES('','$profileImageFake','$name','$age','$phoneNumber','$role') "; 
                $query = $object -> connect() -> query($sql);

                // insert using function
                // $attribute = array('cardImage','cardName','cardAge','cardPhonenumber','cardRole');
                // $value     = array(" '$profileImage', '$name', '$age', '$phoneNumber','$role'");
                // $query     = $object->insert($table, $attribute, $value);

                if($query){
                    // echo 
                    // "<script> alert('Succesfully insert to database...');</script>";
                    echo "Sucessfully uploaded...";
                }
                else{
                    echo
                    "<script> alert('Something error...');</script>";
                }
            }
        ?>
        <div class="row divWrap overflow-auto" style="height:600px" id="divWrap">
            <?php
                        $sql = "SELECT * FROM biu_tbl_card";
                        $query = $object -> connect() -> query($sql);
                        
                        while($row = mysqli_fetch_assoc($query)){
                            $getImgName = $row["cardImage"];
                            $cardID = $row["cardID"];
                            $name   = $row["cardName"];
                            echo 
                            "<div class='col-3 pt-2'>";?>
                                <div class='card'>
                                
                                    <img src='assets/img/profilePic.jpg' style='width:100%'>
                                    <h1 class='text-center'><kbd><?php echo $name ?></kbd></h1>
                                    <p class='title text-center'>Hello I am <strong><?php echo $name ?></strong> I study at <strong>Beltei International University.</strong>
                                        I was born in <?php echo $day."/".$month."/".$year ?>.
                                    </p>
                                    <p class='text-start p-3'><?php echo $role ?></p>
                                    <div style='margin: 24px 0;'>
                                        <a href='#'><i class='fa fa-facebook'></i></a>
                                        <a href='#'><i class='fa fa-Telegram'></i></a>
                                        <a href='#'><i class='fa fa-Youtube'></i></a>
                                    </div>
                                    <div class='option p-3'>
                                        <a href='#' class='btn btn-success' onclick='displayEdit()'>Edit</a>
                                        <a href='#' class='btn btn-danger'>Delete</a>
                                    </div>
                                </div>
                            <?php 
                            echo "</div>"  
                            ;}
                ?>
        </div>
        <!-- ====Update=== -->
        <div class="row">
                    <div class="col-lg-12">
                        <div class="editBoxBtn btn btn-danger text-right" id="editBoxBtn" onclick="clearEdit()">X</div>
                        <div class="overflow-auto" id="editBox">
                            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
                                <h1 class="title fs-3 text-uppercase text-center pb-3 ">Edit</h1>
                                <div class="circle profilePreviewBx circle-sm bg-secondary" >
                                    <input type="file" name="editProfileImage" id="editProfileInput" onchange="editPreview()">
                                    <img src="" alt="" id="editProfilePreview" >
                                    <button type="button" onclick="editCancelPreview()" class="buttonClose btn btn-close btn-close-warning" aria-label="Close"></button>
                                    <!-- <img src="assets/icons/Spinner-1s-200px.svg" class="loarding" alt=""> -->
                                </div>
                                <!-- <input type="text" name="getImgName" id="getImgName" value=""> -->
                                <label for="name">Name</label>
                                <input type="text" name="name" class="form-control" placeholder="name" required value="" >
                                <label for="dob">Date of Birth</label>
                                <div class="dob">
                                    <select name="day" id="day">
                                        <option value="" hidden>Day</option>
                                    </select>
                                    <select name="month" id="month">
                                        <option value="" hidden>Month</option>
                                    </select>
                                    <select name="year" id="year">
                                        <option value="" hidden>Year</option>
                                    </select>
                                </div>
                                <label for="phoneNumber">Phone Number</label>
                                <input type="number" name="phoneNumber" class="form-control" required value="">
                                <label for="role">Role</label>
                                <input type="text" name="role" class="form-control" value="">
                                <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary mt-3 text-center">
                            </form>
                        </div>
                    </div>
        </div>        
        <div class="row"></div>
    </div>
    
    <script type="text/javascript">
        function displayForm(){
            var divWrap = document.getElementById("divWrap");
            var formBox = document.getElementById("formBox");
            var closeBtn = document.getElementById("closeFormBox");
            formBox.style.visibility = "visible";
            formBox.style.opacity = "1";
            formBox.style.display = "block";
            divWrap.style.filter  = "blur(3px)";
            // close btn
            closeBtn.style.visibility = "visible";
            closeBtn.style.opacity = "1";
            closeBtn.style.display = "block";
            

        }
        function clearDisplayForm(){
            var formBox = document.getElementById("formBox");
            var closeBtn = document.getElementById("closeFormBox");
            formBox.style = "visibility:none; opacity:0; display:none";
            divWrap.style.filter  = "none";
            
            // close btn
            closeBtn.style.visibility = "none";
            closeBtn.style.opacity = "0";
            closeBtn.style.display = "none";
        }

        // start edit
        function displayEdit(){
            var edit = document.getElementById("editBox");
            var divWrap = document.getElementById("divWrap");
            var editCloseBtn = document.getElementById("editBoxBtn");
            edit.style.display = "block";
            divWrap.style.filter = "blur(2px)";
            // close edit btn
            editCloseBtn.style.visibility = "visible";
            editCloseBtn.style.opacity = "1";
            editCloseBtn.style.display = "block";
        }
        function clearEdit(){
            var edit = document.getElementById("editBox");
            var editCloseBtn = document.getElementById("editBoxBtn");
            edit.style.display = "none";
            divWrap.style.filter = "none";
            // close edit btn
            editCloseBtn.style.visibility = "none";
            editCloseBtn.style.opacity = "0";
            editCloseBtn.style.display = "none";
        }
        // end edit




        // show image function
        function preview(){
            var previewImg = document.getElementById("profilePreview");
            previewImg.src = URL.createObjectURL(event.target.files[0]);
            
            var getImgName = document.getElementById("getImgName");
            getImgName.value = previewImg.src;
        }
        function cancelPreview(){
            document.getElementById("profileInput").value = null;
            var previewImg = document.getElementById("profilePreview");
            previewImg.src = "";
        }
        // function dianableUpload(){
        //     var profilePreview = document.getElementById("profilePreview").value;
        //     var profileInput   = document.getElementById("profileInput");
        //     if(profilePreview!=0){
        //         profileInput.style.display="none";
        //     }
        // }
        
        // ===Edit Profile preview
        function editPreview(){
            var editPreviewImg = document.getElementById("editProfilePreview");
            editPreviewImg.src = URL.createObjectURL(event.target.file[0]);

            var editGetImgName = document.getElementById("editGetImgName");
            editGetImgname.value = editPreviewImg.src;

        }
        function editCancelPreview(){
            document.getElementById("editProfileInput").value = null;
            var editPreviewImg = document.getElementById("editProfilePreview");
            editPreviewImg.src = "";
        }

        // Date condition
        const daySelect = document.getElementById("day");
        const monthSelect = document.getElementById("month");
        const yearSelect  = document.getElementById("year");
        
        const months = ["January", "Febuary","March", "April","August", "May", "June", "July", "September", "October", "November", "December"  ];        
        (function populateMonths(){
            for(let i=0; i<months.length; i++){
                const option = document.createElement("option");
                option.textContent = months[i];
                monthSelect.appendChild(option);
            }
        })();   
        function populateDay(month){
            // if do exits
            while(daySelect.firstChild){
                daySelect.removeChild(daySelect.firstChild);
            }
            // number of day base on month
            let dayNum;
            if(month === "January" || month === "March" || month === "August" || month === "June"  || month === "July" || month === "October" || month === "December"){
                dayNum = 31;
            }else if(month === "April" || month === "May" || month === "September" || month === "November"){
                dayNum = 30;
            }
            // insert day to select option in html
            for(let i=1; i<=dayNum; i++){
                const option = document.createElement("option");
                option.textContent = i;
                daySelect.appendChild(option);
            }

        }
        
        populateDay(monthSelect.value);
                                    
        
    </script>
</body>
</html>